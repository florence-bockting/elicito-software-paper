import elicito as el
import matplotlib.pyplot as plt
import tensorflow as tf
import seaborn as sns

eliobj1 = el.utils.load(file="saved_eliobj/eliobj_param.pkl")

#%%
def r2(y, mu):
    return tf.divide(
        tf.math.reduce_variance(mu, axis=-1),
        tf.math.reduce_variance(y, axis=-1)
    )

#%% plot target quantities
gr0 = tf.reshape(eliobj1.results[0]["model_samples"]["y_gr0"], (128*200*30,))
gr1 = tf.reshape(eliobj1.results[0]["model_samples"]["y_gr1"], (128*200*30,))
gr2 = tf.reshape(eliobj1.results[0]["model_samples"]["y_gr2"], (128*200*30,))
y = eliobj1.results[0]["model_samples"]["y"]
mu = eliobj1.results[0]["model_samples"]["mu"]

R2 = r2(y, mu)

_, axs = plt.subplots(1, 2, constrained_layout=True, figsize=(6,3))
for i, gr in enumerate([gr0, gr1, gr2]):
    sns.histplot(gr,label=f"group-{i}", stat="probability", kde=True,
                 ax=axs[0], alpha=0.2)
sns.histplot(tf.reshape(R2, (128*200,)), stat="probability", ax=axs[1])
axs[0].legend(handlelength=0.3)
axs[1].set_title("R2")
axs[0].set_title("y | group")
axs[0].set_xlim(-3, 7)
axs[1].set_xlim(0, 1)
plt.show()

#%% plot elicited statistics
q_gr0 = tf.reduce_mean(eliobj1.results[0]["elicited_statistics"]["quantiles_y_gr0"], 0)
q_gr1 = tf.reduce_mean(eliobj1.results[0]["elicited_statistics"]["quantiles_y_gr1"], 0)
q_gr2 = tf.reduce_mean(eliobj1.results[0]["elicited_statistics"]["quantiles_y_gr2"], 0)
q_r2 = tf.reduce_mean(eliobj1.results[0]["elicited_statistics"]["quantiles_r2"], 0)

_, axs = plt.subplots(1, 2, constrained_layout=True, figsize=(6,3))
for i, q in enumerate([q_gr0, q_gr1, q_gr2]):
    axs[0].plot(q, [i,i,i], "-o")
axs[0].set_yticks([0., 1., 2.], ["group-0", "group-1", "group-2"])
axs[1].plot(q_r2, [1,1,1], "-o")
axs[1].set_title("R2")
axs[0].set_title("y | group")
axs[1].set_yticks([])
axs[0].set_xlabel(r"$Q_p(y | group)$")
axs[1].set_xlabel(r"$Q_p(R^2)$")
plt.show()

#%%



eliobj1.results = [eliobj1.results]
eliobj1.history = [eliobj1.history]

el.plots.loss(eliobj1, figsize=(6,2))
el.plots.hyperparameter(eliobj1, figsize=(6,4))
el.plots.elicits(eliobj1, figsize=(6,2))
el.plots.prior_marginals(eliobj1, figsize=(6,2))
