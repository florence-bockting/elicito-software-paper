import tensorflow as tf
import tensorflow_probability as tfp
import elicito as el
import pandas as pd

tfd = tfp.distributions
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt

dat = pd.read_csv("internal/combined_co2_q50.csv")
dat_co2 = dat[(dat.year >= 2010) & (dat.year <= 2020)][["year", "month", "lat", "lon", "value_co2"]].drop_duplicates()
dat_month = dat_co2.groupby(["year","month"]).agg({"value_co2":"mean"}).reset_index()
dat_month["time_ym"] = dat_month.year + dat_month.month
dat_month["value_co2"] = dat_month.value_co2-dat_month.value_co2.mean()
plt.plot(dat_month["value_co2"])
plt.show()

class NormalLoc:
    def __init__(self, scale):
        self.scale = scale
    def __call__(self, loc):
        return tfd.Normal(loc=loc, scale=self.scale)

def squared_euclidean_distance(x):
    x = tf.expand_dims(x, -1)
    xx = tf.matmul(x, x, transpose_b=True)
    diag = tf.experimental.numpy.diagonal(xx, axis1=1, axis2=2)
    squared_distance = diag[:, :, None] - 2 * xx + diag[:, None, :]
    return squared_distance[:,None,:,:]

class RBFKernel:
    def __init__(self, length_scale, amplitude):
        self.length_scale = length_scale
        self.amplitude = amplitude

    def __call__(self, x):
        return self.amplitude ** 2 * tf.exp(
            -tf.divide(
                squared_euclidean_distance(x),
                2 * self.length_scale ** 2
            ))

class NoiseKernel:
    def __init__(self, length_scale_cor_noise, sigma_cor_noise, sigma_ind_noise):
        self.length_scale_cor_noise = length_scale_cor_noise
        self.sigma_cor_noise = sigma_cor_noise
        self.sigma_ind_noise = sigma_ind_noise

    def __call__(self, x):
        cor_noise_component = self.sigma_cor_noise ** 2 * tf.exp(
            -tf.divide(squared_euclidean_distance(x),
                       2 * self.length_scale_cor_noise ** 2
                      ))
        ind_noise_component = self.sigma_ind_noise ** 2 * tf.where(
            squared_euclidean_distance(x) == 0, 1., 0.)

        return cor_noise_component + ind_noise_component

class LocalPeriodicKernel:
    def __init__(self, magnitude, decay_time, smoothness):
        self.magnitude = magnitude
        self.decay_time = decay_time
        self.smoothness = smoothness

    def __call__(self, x):
        return self.magnitude ** 2 * tf.exp(-tf.subtract(
            tf.divide(squared_euclidean_distance(x),
                      2 * self.decay_time ** 2),
            tf.divide(2 * tf.math.sin(np.pi * tf.sqrt(squared_euclidean_distance(x))) ** 2,
                      self.smoothness ** 2)
        ))

class RationalQuadraticKernel:
    def __init__(self, magnitude, length_scale, length_scale_diffuse):
        self.magnitude = magnitude
        self.length_scale = length_scale
        self.length_scale_diffuse = length_scale_diffuse

    def __call__(self, x):
        return (self.magnitude ** 2) * (
            1. + tf.divide(
            squared_euclidean_distance(x),
            2 * self.length_scale_diffuse * (self.length_scale ** 2)
        )) ** (-self.length_scale_diffuse)


class GenerativeModel:
    def __call__(self, prior_samples, timeseries, RBFKernel,
                 LocalPeriodicKernel, RationalQuadraticKernel, NoiseKernel):
        B, M, P = prior_samples.shape
        # set up kernels for modelling the covariance matrix
        global_trend = RBFKernel(
            length_scale=prior_samples[:,:,0][:,:,None,None],
            amplitude=prior_samples[:,:,1][:,:,None,None]
        )

        seasonal_trend = LocalPeriodicKernel(
            magnitude=prior_samples[:,:,2][:,:,None,None],
            decay_time=prior_samples[:,:,3][:,:,None,None],
            smoothness=prior_samples[:,:,4][:,:,None,None],
        )

        irregularities = RationalQuadraticKernel(
            magnitude=prior_samples[:,:,5][:,:,None,None],
            length_scale=prior_samples[:,:,6][:,:,None,None],
            length_scale_diffuse=prior_samples[:,:,7][:,:,None,None],
        )

        noise = NoiseKernel(
            length_scale_cor_noise=prior_samples[:,:,8][:,:,None,None],
            sigma_cor_noise=prior_samples[:,:,9][:,:,None,None],
            sigma_ind_noise=prior_samples[:,:,10][:,:,None,None],
        )

        cov = global_trend(timeseries)  + seasonal_trend(timeseries) + irregularities(timeseries) + noise(timeseries)
        mu = tf.zeros((B, M, cov.shape[-1]), dtype=tf.float32)

        # predict data
        y_gen = tfd.MultivariateNormalTriL(mu, tf.linalg.cholesky(cov)).sample()

        res_dict = {f"y_{i}": tf.reduce_mean(y_gen[:,:,i],1) for i in range(y_gen.shape[-1])}
        res_dict["ypred"] = tf.reduce_mean(y_gen,1)
        res_dict["y_pred"] = y_gen
        return res_dict

timeseries = tf.cast(
    tf.broadcast_to(
        tf.expand_dims(dat_month.time_ym,0),
        (128,len(dat_month.value_co2))),
        dtype=tf.float32)



model = el.model(obj=GenerativeModel,
                 timeseries=timeseries,
                 RBFKernel=RBFKernel,
                 LocalPeriodicKernel=LocalPeriodicKernel,
                 RationalQuadraticKernel=RationalQuadraticKernel,
                 NoiseKernel=NoiseKernel)

parameters = [
    el.parameter(
        name=n,
        family=tfd.HalfNormal,#NormalLoc(scale=0.1),
        hyperparams=dict(scale=el.hyper(f"loc_{n}", lower=0),
                       #  scale=el.hyper(f"scale_{n}", lower=0)
                         )
    ) for n in ["ls_trend", "amplitude_trend",
            "magnitude_season", "decay_time_season", "smoothness_season",
            "magnitude_irr", "length_scale_irr", "length_scale_diffuse_irr",
            "length_scale_cor_noise", "sigma_cor_noise", "sigma_ind_noise"
                ]
]

targets=[
            el.target(
                name=f"y_{i}",
                query=el.queries.identity(),
                loss=el.losses.MMD2(kernel="energy")
            ) for i in range(7)
        ] + [
            el.target(
                name="ypred",
                query=el.queries.identity(), #quantiles((0.05, 0.25, 0.5, 0.75, 0.95)),
                loss=el.losses.MMD2(kernel="energy")
            )
]

el.utils.get_expert_datformat(targets)

dat = {f'identity_y_{i}': dat_month.value_co2[i] for i in range(7)}
dat["identity_ypred"] = dat_month.value_co2
expert = el.expert.data(
    dat=dat,
)

optimizer=el.optimizer(
    optimizer=tf.keras.optimizers.Adam,
    learning_rate=0.1
)

trainer=el.trainer(
    method="parametric_prior",
    seed=2,
    epochs=500,
    progress=1
)

hyperparams_ini = {f"loc_{n}": i for n,i in zip(
    ["ls_trend", "amplitude_trend",
     "magnitude_season", "decay_time_season", "smoothness_season",
     "magnitude_irr", "length_scale_irr", "length_scale_diffuse_irr",
    "length_scale_cor_noise", "sigma_cor_noise", "sigma_ind_noise"
     ],
    [15., 10., 5., 1., 1.]+[.1]*4+[1., .1]
)}

initializer=el.initializer(
    method=None,
    hyperparams=hyperparams_ini
)

eliobj = el.Elicit(
    model=model,
    parameters=parameters,
    targets=targets,
    expert=expert,
    optimizer=optimizer,
    trainer=trainer,
    initializer=initializer
)

eliobj.fit()

el.plots.loss(eliobj)
el.plots.elicits(eliobj)
el.plots.hyperparameter(eliobj)

prior_samples = eliobj.results[0]["prior_samples"]
gm = GenerativeModel()
res = gm(
    prior_samples=prior_samples,
    timeseries=timeseries,
    RBFKernel=RBFKernel,
    LocalPeriodicKernel=LocalPeriodicKernel,
    RationalQuadraticKernel=RationalQuadraticKernel,
    NoiseKernel=NoiseKernel)

plt.plot(timeseries[0,:],
         tf.reduce_mean(res["y_pred"], (0,1)),
         "-o", label="model")
plt.plot(timeseries[0,:], dat_month.value_co2,
         "-o", label="obs")
plt.legend()
plt.show()